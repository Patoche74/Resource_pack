# CustomGUI Resource Pack

This resource pack provides custom textures for different menu types in the CustomGUI plugin.

## 🎨 How It Works

The plugin uses custom `InventoryHolder` classes to trigger different textures:
- **ShopMenuHolder** → `shop_menu_54.png`
- **WarpMenuHolder** → `warp_menu_54.png`  
- **AdminMenuHolder** → `admin_menu_54.png`
- **TestMenuHolder** → `test_menu_54.png`
- **DefaultMenuHolder** → `default_menu_54.png`

## 📁 File Structure

```
CustomGUI_ResourcePack/
├── pack.mcmeta                    # Resource pack metadata
├── README.md                      # This file
└── assets/minecraft/textures/gui/container/
    ├── generic_54.png            # Default chest texture (vanilla)
    ├── shop_menu_54.png          # Shop menu texture
    ├── warp_menu_54.png          # Warp menu texture
    ├── admin_menu_54.png         # Admin menu texture
    ├── test_menu_54.png          # Test menu texture
    └── default_menu_54.png       # Default menu texture
```

## 🚀 Installation

1. **Place your custom PNG files** in the `assets/minecraft/textures/gui/container/` folder
2. **Zip the entire folder** and rename it to `CustomGUI_ResourcePack.zip`
3. **Place the zip file** in your server's `resource-packs` folder
4. **Enable the resource pack** in your server.properties or through commands

## 🎯 Texture Requirements

- **Size**: 256x256 pixels (standard Minecraft GUI texture size)
- **Format**: PNG with transparency support
- **Naming**: Must match exactly (e.g., `shop_menu_54.png`)

## 🔧 Customization

### Adding New Menu Types:
1. Create a new holder class in the plugin (e.g., `CraftingMenuHolder`)
2. Add it to the `HolderFactory`
3. Create the corresponding PNG texture
4. Update your `menus.yml` to use the new texture type

### Example menus.yml:
```yaml
crafting_menu:
  title: "&6&lCrafting"
  size: 54
  texture: "crafting"  # Will use CraftingMenuHolder
  items:
    # ... menu items
```

## 📝 Notes

- **54 slots**: All menus maintain 54 slots (double chest size)
- **Different textures**: Each menu type can have a unique visual appearance
- **Resource pack required**: Players must have this resource pack to see custom textures
- **Fallback**: If texture not found, vanilla chest texture is used

## 🎨 Texture Design Tips

- **Consistent sizing**: Keep important UI elements in the same positions
- **Transparency**: Use transparency for better integration
- **Color themes**: Match your server's visual style
- **Readability**: Ensure text and items remain visible
