CUSTOM TEXTURE FILES NEEDED:

This folder should contain the following PNG texture files:

1. shop_menu_54.png     - Texture for shop menus (ShopMenuHolder)
2. warp_menu_54.png     - Texture for warp menus (WarpMenuHolder)  
3. admin_menu_54.png    - Texture for admin menus (AdminMenuHolder)
4. test_menu_54.png     - Texture for test menus (TestMenuHolder)
5. default_menu_54.png  - Texture for default menus (DefaultMenuHolder)

TEXTURE REQUIREMENTS:
- Size: 256x256 pixels (standard Minecraft GUI texture size)
- Format: PNG with transparency support
- Naming: Must match exactly as shown above

HOW TO CREATE:
1. Use any image editor (Photoshop, GIMP, Paint.NET, etc.)
2. Create a 256x256 pixel canvas
3. Design your custom GUI background
4. Save as PNG with the exact filename
5. Place in this folder

EXAMPLE TEXTURE NAMES:
- shop_menu_54.png     → ShopMenuHolder class
- warp_menu_54.png     → WarpMenuHolder class
- admin_menu_54.png    → AdminMenuHolder class
- test_menu_54.png     → TestMenuHolder class
- default_menu_54.png  → DefaultMenuHolder class

The plugin will automatically use these textures based on the "texture" field in your menus.yml file!
